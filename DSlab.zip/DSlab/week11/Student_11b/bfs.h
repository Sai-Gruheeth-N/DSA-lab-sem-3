#include <stdio.h>
#include <stdlib.h>

// Checks if there exists a path between u and v.
// Returns 1 if a path is present, returns 0 otherwise.
int check_path(int **graph, int n, int u, int v);
